import streamlit as st
from forms.contact import contact_form


@st.dialog("Contacto directo")
def show_contact_form():
    contact_form()

st.title("💻 AutomatizAndo Ando")
st.write("\n")
st.write("\n")

col1, col2 = st.columns(2, gap="large", vertical_alignment="center")
with col1:
    st.image("./resources/profile_image.jpg", use_container_width = True)

with col2:
    st.title("Jose Pampa", anchor=False)
    st.write(
        "Especialista en datos, ayudando a empresas a transformar información en decisiones inteligentes a través de soluciones tecnológicas e innovadoras."
    )
    if st.button("✉️ Contacto", use_container_width = True):
        show_contact_form()
    st.write("\n")

st.write("\n")
st.subheader("Experiencia", anchor=False)
st.write(
    """
    - **+4 años de experiencia** trabajando en área de tecnología, innovación y comercial.  
    - Experiencia en el sector de **seguros**, **banca**, **salud**, **marketing** y **educación**.
    """
)

st.write("\n")
st.subheader("Manager Skills", anchor=False)
st.write(
    """
    - Sólida experiencia práctica con dominio de códigos de programación como Python, R, etc.
    - Buen entendimiento de principios estadísticos y su aplicación en contextos reales.
    - Excelente capacidad para trabajar en equipo y destacada proactividad en la ejecución de tareas.
    """
)

st.write("\n")
st.subheader("Skills programación", anchor=False)
st.write(
    """
    - 🚀 Analytics: SAS Enterprise Guide. SAS Miner. STATA. SPSS. CANCEIS. MATLAB. Octave. WEKA. Knime. Python. R. Spark. Jupyter. JavaScript. Machine Learning Studio, Cloudera, Google Analytics, Julia, PHP, html, CSS, app script.
    - 💾 BBDD: AWS, Azure, Oracle. SQL Server. My SQL. Teradata. SAP HANA, PostgreSQL, Mongo DB, SQLite, Big Query, Snowflake.
    - 📊 Data Viz: Reportlab. Power BI. Tableau. Shiny. Plotly. Qlik Sense, SAS Graph, SAS Visual Analytics. Sisense, D3, Superset, Data Studio, Looker, Superset.
    - ⚙️ Softwares: Hubspot API, Facebook API, Instagram API, Salesforce API, TikTok API, Vtiger, Zoho CRM, Microsoft Dynamics 365, Monday.com, Pipedrive, Freshsales, Zendesk Sell, Oracle CRM.
    - 💻 Skills IA: TensorFlow, PyTorch, Keras. SpaCy, NLTK, Transformers. OpenCV, YOLO, TensorFlow Object Detection. OpenAI Gym, Stable Baselines. GANs, VAEs. Facebook Prophet, ARIMA, LSTMs, XGBoost. H2O.ai, DataRobot, Auto-sklearn. MLflow, TensorFlow Serving, Docker, Kubernetes, Streamlit, Flask, FastAPI. Genetic Algorithms.
    """
)