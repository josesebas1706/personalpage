import streamlit as st

st.title("💻 AutomatizAndo Ando")

st.write("Hola")